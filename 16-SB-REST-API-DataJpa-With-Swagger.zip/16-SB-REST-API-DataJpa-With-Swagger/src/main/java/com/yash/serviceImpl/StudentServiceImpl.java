package com.yash.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.model.Address;
import com.yash.model.Student;
import com.yash.repository.AddressRepository;
import com.yash.repository.StudentRepository;
import com.yash.service.StudentService;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentRepository sturepo;

	@Autowired
	private AddressRepository addrepo;

	@Override
	public int saveStudent(Student student) {
		return sturepo.save(student).getSid();
	}
	@Override
	public void updateStudent(Student student) {
		sturepo.save(student);
	}
	@Override
	public void deleteEmployee(int id) {
		sturepo.deleteById(id);
	}
	@Override
	public Optional<Student> getOneStudent(int id) {
		return sturepo.findById(id);
	}
	@Override
	public List<Student> getAllStudent() {
		return sturepo.findAll();
	}
	@Override
	public Optional<Student> isPresent(int id) {
		return sturepo.findById(id);
	}
	@Override
	public int saveAdress(Address address) {
		return addrepo.save(address).getAreacode();
	}
	@Override
	public List<Address> getAllAdress() {
		return addrepo.findAll();
	}
	@Override
	public boolean isStudentPresent(int id) {
		return sturepo.existsById(id);
	}
}

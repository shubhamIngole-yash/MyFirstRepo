package com.yash.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.model.Student;
import com.yash.service.StudentService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/student")
public class StudentController {

	@Autowired
	private StudentService stuser;

	@ApiOperation(value = "This method is going to save all information about the Student...")
	@PostMapping(value = "/save")
	public ResponseEntity<String> saveStudent(@RequestBody Student student) {
		stuser.saveStudent(student);
		String msg = "Student save successfully with id : " + student.getSid();
		return new ResponseEntity<String>(msg, HttpStatus.CREATED);
	}

	@ApiOperation(value = "This method is going to retive all Students...")
	@GetMapping(value = "/getAll")
	public ResponseEntity<List<Student>> getAllStudent() {
		List<Student> allStudent = stuser.getAllStudent();
		return new ResponseEntity<List<Student>>(allStudent, HttpStatus.OK);
	}

	@ApiOperation(value = "This method gives us perticular Student data according to Student_Id...")
	@GetMapping(value = "/getById/{id}")
	public ResponseEntity<Object> findById(@PathVariable int id) {
		Optional<Student> student = stuser.getOneStudent(id);
		return new ResponseEntity<Object>(student, HttpStatus.OK);

	}

	@ApiOperation(value = "This method is going to check whether Student is available or not...")
	@GetMapping(value = "/isPresent/{id}")
	public ResponseEntity<String> isPresent(@PathVariable int id) {
		Optional<Student> present = stuser.isPresent(id);
		if (present.isPresent()) {
			String msg = "Student with id = " + id + " is present...!!";
			return new ResponseEntity<String>(msg, HttpStatus.OK);
		} else {
			String msg = "Student with id = " + id + " is Not present...!!";
			return new ResponseEntity<String>(msg, HttpStatus.BAD_REQUEST);
		}
	}

	@ApiOperation(value = "This method is going to update all information about the Student...")
	@PutMapping("/update")
	public ResponseEntity<String> updateStudent(@RequestBody Student student) {
		boolean present = stuser.isStudentPresent(student.getSid());
		if (present) {
			stuser.updateStudent(student);
			String msg = "Student data with id = " + student.getSid() + " is updated successfully...!!";
			return new ResponseEntity<String>(msg, HttpStatus.OK);
		} else {
			String msg = "Student data with id = " + student.getSid() + " is not found...!!";
			return new ResponseEntity<String>(msg, HttpStatus.OK);
		}
	}

	@ApiOperation(value = "This method is going to delete perticular Student")
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteById(@PathVariable int id) {
		System.out.println("=============");
		boolean studentPresent = stuser.isStudentPresent(id);
		System.out.println(studentPresent);
		if (studentPresent) {
			stuser.deleteEmployee(id);
			return new ResponseEntity<String>("Student with id = " + id + " is deleted successfully...!!",
					HttpStatus.OK);
		} else {
			return new ResponseEntity<String>("Student with id = " + id + " is not available...!!",
					HttpStatus.BAD_REQUEST);
		}
	}
}

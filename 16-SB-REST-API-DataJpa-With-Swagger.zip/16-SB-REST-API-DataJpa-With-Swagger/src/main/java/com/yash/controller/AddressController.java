package com.yash.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.model.Address;
import com.yash.service.StudentService;

@RestController
@RequestMapping("/address")
public class AddressController {
	
	@Autowired
	private StudentService stuser;
	
	@PostMapping("/save")
	public String saveAddress(@RequestBody Address address) {	
		stuser.saveAdress(address);
		return "Address save successfully...!! ";		
	}	
	@GetMapping("/getAllAddress")
	public ResponseEntity<List<Address>> getAllAddress(){	
		List<Address> allAdress = stuser.getAllAdress();
		return new ResponseEntity<List<Address>>(allAdress, HttpStatus.OK);
	}
}

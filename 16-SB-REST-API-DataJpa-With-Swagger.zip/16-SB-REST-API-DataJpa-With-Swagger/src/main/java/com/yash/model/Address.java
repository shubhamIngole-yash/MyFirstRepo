package com.yash.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@XmlRootElement
public class Address {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int areacode;
	private String cityname;
	private String statename;
	public Address() {
		// TODO Auto-generated constructor stub
	}
	public int getAreacode() {
		return areacode;
	}
	public void setAreacode(int areacode) {
		this.areacode = areacode;
	}
	public String getCityname() {
		return cityname;
	}
	public void setCityname(String cityname) {
		this.cityname = cityname;
	}
	public String getStatename() {
		return statename;
	}
	public void setStatename(String statename) {
		this.statename = statename;
	}
	@Override
	public String toString() {
		return "Address [areacode=" + areacode + ", cityname=" + cityname + ", statename=" + statename + "]";
	}
	public Address(int areacode, String cityname, String statename) {
		super();
		this.areacode = areacode;
		this.cityname = cityname;
		this.statename = statename;
	}
	
}

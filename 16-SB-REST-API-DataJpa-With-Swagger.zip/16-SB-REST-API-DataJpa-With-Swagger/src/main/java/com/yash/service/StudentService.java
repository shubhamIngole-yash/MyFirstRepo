package com.yash.service;

import java.util.List;
import java.util.Optional;

import com.yash.model.Address;
import com.yash.model.Student;

public interface StudentService {
	
	public int saveStudent(Student student);
	public void updateStudent(Student student);
	public void deleteEmployee(int id);
	public Optional<Student> getOneStudent(int id);
	public List<Student> getAllStudent();
	public Optional<Student> isPresent(int id);
	public boolean isStudentPresent(int id);
	public int saveAdress(Address address);
	public List<Address> getAllAdress();

}

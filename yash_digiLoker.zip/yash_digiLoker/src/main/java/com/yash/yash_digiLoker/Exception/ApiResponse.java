package com.yash.yash_digiLoker.Exception;

public class ApiResponse {
	
	String msg;
	boolean success;
	
	public ApiResponse(String msg, boolean success) {
		super();
		this.msg = msg;
		this.success = success;
	}
	
	

}

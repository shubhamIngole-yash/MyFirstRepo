package com.yash.yash_digiLoker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YashDigiLokerApplicationTests {

	@Test
	void contextLoads() {
	}

}
